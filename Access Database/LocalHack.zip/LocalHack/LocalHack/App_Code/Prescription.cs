﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LocalHack.App_Code
{
    public class Prescription
    {
        public int prescriptionId;
        public int patientId;
        public float dose;
        public int noMedications;
        public String unit;
        public String frequency;
        public String medName;
        public String assessDate;
    }
}