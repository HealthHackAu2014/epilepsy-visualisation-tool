﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LocalHack.App_Code
{
    public class SeizureManager : Database
    {
        public void Save(Seizure obj)
        {
            String query  = "INSERT INTO seizure";
                   query += "(patientId,assessDate,frequency,episode,confidence)";
                   query += @" VALUES( " +
                            obj.patientId + ",'" +
                            obj.assessDate + "','" +
                            obj.frequency + "'," +
                            obj.episode + "," +
                            obj.confidence + ")";
        }

        public Seizure FetchById(int id)
        {
            Seizure temp = new Seizure();

            this.ExecuteQuery("SELECT * FROM seizures WHERE patientId = " + id);

            while(reader.Read())
            {
                Int32.TryParse(reader["seizureId"].ToString(), out temp.seizureId);
                Int32.TryParse(reader["patientId"].ToString(), out temp.patientId);
                temp.assessDate = reader["assessDate"].ToString();
                temp.frequency = reader["frequency"].ToString();
                Int32.TryParse(reader["episode"].ToString(), out temp.episode);
                Int32.TryParse(reader["confidence"].ToString(), out temp.confidence);
            }

            comm.Dispose();

            return temp;
        }

        public List<Seizure> FetchAll()
        {
            List<Seizure> objs = new List<Seizure>();

            this.ExecuteQuery("SELECT * FROM seizures");

            while(reader.Read())
            {
                Seizure temp = new Seizure();

                Int32.TryParse(reader["seizureId"].ToString(), out temp.seizureId);
                Int32.TryParse(reader["patientId"].ToString(), out temp.patientId);
                temp.assessDate = reader["assessDate"].ToString();
                temp.frequency = reader["frequency"].ToString();
                Int32.TryParse(reader["episode"].ToString(), out temp.episode);
                Int32.TryParse(reader["confidence"].ToString(), out temp.confidence);

                objs.Add(temp);
            }

            comm.Dispose();

            return objs;
        }
    }
}