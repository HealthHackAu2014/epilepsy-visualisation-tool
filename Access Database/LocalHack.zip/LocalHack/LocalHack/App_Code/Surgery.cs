﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LocalHack.App_Code
{
    public class Surgery
    {
        public int surgeryId;
        public int patientId;
        public String surgeryDate;
        public String surgeryType;
    }
}