﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace LocalHack.App_Code
{
    public class Database
    {
        protected SqlConnection conn;
        protected SqlCommand comm;
        protected SqlDataReader reader;

        public Database()
        {
            conn = Connection();
            comm = Command();
        }

        public SqlConnection Connection()
        {
            return new SqlConnection(ConfigurationManager.ConnectionStrings["sqlConnection"].ToString());
        }

        public SqlCommand Command()
        {
            return new SqlCommand();
        }

        public void ExecuteQuery(String query)
        {
            conn.Open();
            comm.CommandText = query;
            comm.ExecuteNonQuery();
            conn.Close();
        }

        public void ExecuteNonQuery(String query)
        {
            conn.Open();
            comm.CommandText = query;
            comm.ExecuteNonQuery();
            conn.Close();
        }
    }
}