﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LocalHack.App_Code
{
    public class Test
    {
    }
}