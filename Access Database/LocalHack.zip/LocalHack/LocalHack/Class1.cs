﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LocalHack
{
    public class Class1
    {
    }
}