﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;

namespace LocalHack
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
    
        }

        protected DataSet ScrapeData(string FilePath)
        {
            OleDbConnection Connection = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + ";Extended Properties=Excel 12.0 XML");
            DataSet TableData = new DataSet();
            using (Connection)
            {
                Connection.Open();
                OleDbCommand Reader = new OleDbCommand();
                Reader.Connection = Connection;
                DataTable dtSheet = Connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                foreach (DataRow dr in dtSheet.Rows)
                {
                    string Sheet = dr["TABLE_NAME"].ToString();
                    if (!Sheet.EndsWith("$"))
                        continue;
                    else if (Sheet == "Seizures$" || Sheet == "Meds$" || Sheet == "Surgery$")
                    {
                        Reader.CommandText = "SELECT * FROM [" + Sheet + "]";
                        DataTable SubSheet = new DataTable();
                        SubSheet.TableName = Sheet;
                        OleDbDataAdapter Writer = new OleDbDataAdapter(Reader);
                        Writer.Fill(SubSheet);
                        TableData.Tables.Add(SubSheet);
                    }
                }
                Reader = null;
                Connection.Close();
            }
            return TableData;
        }

        protected void Import(DataSet SpreadsheetTables)
        {
            foreach (DataTable Table in SpreadsheetTables.Tables)
            {
                if (Table.TableName == "Seizures$")
                {
                    foreach (DataRow Row in Table.Rows)
                    {
                        if (!String.IsNullOrWhiteSpace(Row[0].ToString()) || !String.IsNullOrWhiteSpace(Row[1].ToString()))
                        {
                            Debug.WriteLine("adding seizures " + Row[0].ToString() + " " + Row[1].ToString());
                        }
                    }
                }
                else if (Table.TableName == "Meds$")
                {
                    foreach (DataRow Row in Table.Rows)
                    {
                        if (!String.IsNullOrWhiteSpace(Row[0].ToString()) || !String.IsNullOrWhiteSpace(Row[1].ToString()))
                            Debug.WriteLine("adding meds " + Row[0].ToString() + " " + Row[1].ToString());
                    }
                }
                else if (Table.TableName == "Surgery$")
                {
                    foreach (DataRow Row in Table.Rows)
                    {
                        if (!String.IsNullOrWhiteSpace(Row[0].ToString()) || !String.IsNullOrWhiteSpace(Row[1].ToString()))
                            Debug.WriteLine("adding surgery " + Row[0].ToString() + " " + Row[1].ToString());
                    }
                }
                else
                    throw new ApplicationException("Invalid Worksheet Name: Only Seizures, Meds and Surgery");
            }
        }

        protected void Upload(object sender, EventArgs e)
        {
            string savePath = @"\temp\uploads\";
            if (FileUpload1.HasFile)
            {
                string FileName = Server.HtmlEncode(FileUpload1.FileName);
                string FileExtension = System.IO.Path.GetExtension(FileName);
                if ((FileExtension == ".xlsx"))
                {
                    savePath += FileName;
                    FileUpload1.SaveAs(savePath);
                    Import(ScrapeData(savePath));

                    UploadStatusLabel.Text = "File was uploaded and processed successfully.";
                }
                else
                    UploadStatusLabel.Text = "File was not in a valid .xlsx format";
            }
        }
    }
}